<!DOCTYPE html>
<html lang="en">
<head>
	<title>Vehicle Info Portal</title>

	<link rel="stylesheet" type="text/css" href="css/responsive.css">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">

</head>

<body>
<div class="topnav">
  <a href="index.php">Home</a>
  <!-- <a href="#">Filter</a>
  <a href="#">Link</a> -->
</div>

<div class="content">
	<section class="">
		

			<section class="caption">
				<h3 class="product" style="text-align: center">Vehicle Details</h3>
			</section>
	</section>


			<?php
						    $conn=mysqli_connect("localhost","root","","mydb");
     
        if (mysqli_connect_errno()){
            echo "Failed to connect to MySQL: " . mysqli_connect_error();
            die();
}
        $sql = "SELECT * FROM products where productCode = '$_GET[pid]'" ;
        $res_data = mysqli_query($conn,$sql);
       $rws = mysqli_fetch_array($res_data);
        
			?>
				
					<a href="#">
						<img class="" src="cars/<?php echo $rws['productLine'];?>.jpg" width="300" height="200">
					</a>
					<h3 class=""><?php echo 'Price(Lakhs).'.$rws['buyPrice'];?></h3>
					
						<h3>
							<a href="#"><?php echo 'Product Type>'.$rws['productLine'];?></a>
						</h3>
						<h3>Product Name/Model: <span class=""><?php echo $rws['productName'];?></span></h3>
						<h3>Product Vendor: <span class=""><?php echo $rws['productVendor'];?></span></h3>
						<h3>Description: <span class=""><?php echo $rws['productDescription'];?></span></h3>
			
			
	</div>
	<div class="footer">
  <p>Copyright@</p>
</div>	
</body>
</html>