<!DOCTYPE html>
<html lang="en">
<head>
	<title>Vehicle Info Portal</title>

	<link rel="stylesheet" type="text/css" href="css/responsive.css">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
	
</head>
<body>
<div class="topnav">
  <a href="index.php">Home</a>
  <!-- <a href="#">Filter</a>
  <a href="#">Link</a> -->

</div>

<div class="content">
	<section class="">

			<section class="caption">
				<h3 class="product" style="text-align: center">Find Vehicle specification</h3>
			</section>
	</section>


	<section class="listings">
		<div class="wrapper">
			<ul class="product_list">
				   <?php
		

        $conn=mysqli_connect("localhost","root","","mydb");
     
        if (mysqli_connect_errno()){
            echo "Failed to connect to MySQL: " . mysqli_connect_error();
            die();
        }
$search = $_POST['search'];
        $sql = "SELECT * FROM products where productName = $search";
          $res_data = mysqli_query($conn,$sql);
   
        while($rws = mysqli_fetch_array($res_data)){

?>
				<li>
					<a href="display.php?pid=<?php echo $rws['productCode'] ?>">
						<img class="thumb" src="cars/<?php echo $rws['productLine'];?>.jpg" width="300" height="200">
					</a>
					<span class="price"><?php echo 'Price(Lakhs).'.$rws['buyPrice'];?></span>
					<div class="product_details">
						<h1>
							<a href="display.php?pid=<?php echo $rws['productCode'] ?>"><?php echo 'Product Type>'.$rws['productLine'];?></a>
						</h1>
						<h2>Product Name/Model: <span class="product_size"><?php echo $rws['productName'];?></span></h2>
					</div>
				</li>

			<?php
				  }
    ?>
			</ul>

		</div>
	</section>	
</div>
	<div class="footer">
  <p>Copyright@</p>
</div>	
	
</body>
</html>