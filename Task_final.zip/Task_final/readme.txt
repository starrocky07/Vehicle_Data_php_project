Vehicle Inventory


Steps:
1)Import the database from db folder.

2)Make changes to the files.
	Default username: root and password:""
	db name: mydb

requirements:
-- php version >5


Sample data taken from given link below...
http://www.mysqltutorial.org/mysql-sample-database.aspx